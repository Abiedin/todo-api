import './userlist.scss'

export const UserList = () => {
  return (
    <>
      <h1 className="userlist-title">UserList</h1>
      <div className="userlist">
        <ul>
          <li>Hanna</li>
          <li>Manna</li>
          <li>Sergry</li>
          <li>Jonas</li>
          <li>Ivan</li>
          <li>Buddi</li>
        </ul>
      </div>
    </>
  )
}